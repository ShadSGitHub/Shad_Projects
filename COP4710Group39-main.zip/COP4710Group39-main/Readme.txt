Front End: Ian, David
Back End: Shady, AJ, Zayne

Front End: React-JS
BackEnd: MERN stack

2/24-3/3 Goals:
Backend: Get Server Running and Determine which server base to use and the Best possible stack to work with
Front End: Set Blueprint for how to lay out website maybe Develop a few pages

3/3-3/10 Goals:
Backend: TBD
FrontEnd: Work through the preset list of pages needed
